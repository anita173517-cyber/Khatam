package com.harindra.iptvpro.vod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VodCinemaUiV231Test {

    @Test
    fun v231DefaultPreferencesEnableCinemaDefaultsWithoutManualSettings() {
        val seekDefault = VodSeekInterval.SEC_10
        assertEquals(10_000L, seekDefault.millis)
        assertEquals(10, seekDefault.seconds)
        assertEquals("10s", seekDefault.label)
        assertEquals(VodAspectRatioMode.FIT, VodAspectRatioMode.fromId("fit"))
        assertEquals(VodAspectRatioMode.FIT, VodAspectRatioMode.fromId(null))
        assertEquals(VodSeekInterval.SEC_10, VodSeekInterval.fromSeconds(10))
    }

    @Test
    fun v231SeriesBadgeFormattingShowsRealSeasonAndEpisodeCountsOnly() {
        fun formatSeriesBadge(seasons: Int, episodes: Int, fallback: String): String = when {
            seasons > 0 && episodes > 0 -> "${seasons}S • ${episodes}E"
            seasons > 0 -> "$seasons Seasons"
            else -> fallback.ifBlank { "SERIES" }
        }
        assertEquals("3S • 24E", formatSeriesBadge(3, 24, ""))
        assertEquals("2 Seasons", formatSeriesBadge(2, 0, ""))
        assertEquals("4K", formatSeriesBadge(0, 0, "4K"))
        assertEquals("SERIES", formatSeriesBadge(0, 0, ""))
    }

    @Test
    fun v231EpisodeLabelAvoidsDuplicateSeasonPrefix() {
        fun formatEp(season: Int, ep: Int, rawTitle: String): String {
            val sPad = season.toString().padStart(2, '0')
            val ePad = ep.toString().padStart(2, '0')
            return if (rawTitle.contains("S$sPad", ignoreCase = true)) {
                rawTitle
            } else {
                "S${sPad}E${ePad}  •  $rawTitle"
            }
        }
        assertEquals("S01E05  •  The Beginning", formatEp(1, 5, "The Beginning"))
        assertEquals("Show - S01E05 Pilot", formatEp(1, 5, "Show - S01E05 Pilot"))
        assertFalse(formatEp(2, 10, "Finale").contains("S01"))
        assertTrue(formatEp(2, 10, "Finale").startsWith("S02E10"))
    }
}
