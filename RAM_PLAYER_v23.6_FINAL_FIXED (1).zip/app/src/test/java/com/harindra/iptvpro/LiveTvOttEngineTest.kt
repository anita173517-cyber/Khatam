package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v23.2 OTT-ENGINE MASTER EDITION — Unit Tests for Dual-Engine Live TV Routing,
 * AC3/E-AC3/DTS/MPEG-2 Detection, Black-Screen Multi-Stage Healing, and Xtream Format Fallback.
 */
class LiveTvOttEngineTest {

    @Test
    fun detectsIndianHdAc3AndDtsAudioCodecs() {
        assertTrue(LiveTvEngineRouter.isProblematicAudioCodec("audio/ac3", "ac-3", 6))
        assertTrue(LiveTvEngineRouter.isProblematicAudioCodec("audio/eac3", "ec-3", 6))
        assertTrue(LiveTvEngineRouter.isProblematicAudioCodec("audio/vnd.dts", "dtsc", 6))
        assertTrue(LiveTvEngineRouter.isProblematicAudioCodec("audio/mpeg-L2", "", 2))
        assertFalse(LiveTvEngineRouter.isProblematicAudioCodec("audio/mp4a-latm", "mp4a.40.2", 2))
    }

    @Test
    fun proactivelySwitchesToLibVlcOnUnsupportedTracksOrAc3DecoderError() {
        assertTrue(
            LiveTvEngineRouter.shouldProactivelySwitchToLibVlc(
                hasUnsupportedVideoTrack = false,
                hasUnsupportedAudioTrack = true,
                audioMimeType = "audio/ac3",
                audioCodecs = "ac-3",
                audioChannelCount = 6,
                audioDecoderError = null,
                audioOutputError = null,
                engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
            )
        )
        assertTrue(
            LiveTvEngineRouter.shouldProactivelySwitchToLibVlc(
                hasUnsupportedVideoTrack = false,
                hasUnsupportedAudioTrack = false,
                audioMimeType = "audio/ac3",
                audioCodecs = "ac-3",
                audioChannelCount = 6,
                audioDecoderError = "MediaCodecAudioRenderer init failed",
                audioOutputError = null,
                engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
            )
        )
        assertFalse(
            LiveTvEngineRouter.shouldProactivelySwitchToLibVlc(
                hasUnsupportedVideoTrack = true,
                hasUnsupportedAudioTrack = true,
                audioMimeType = "audio/ac3",
                audioCodecs = "ac-3",
                audioChannelCount = 6,
                audioDecoderError = "init failed",
                audioOutputError = null,
                engineMode = LiveTvEngineMode.MEDIA3_ONLY
            )
        )
    }

    @Test
    fun blackScreenHealStageProgressionCoversHwSwAndBackupUrl() {
        val s1 = LiveTvEngineRouter.nextHealStage(LiveTvHealStage.EXO_PRIMARY, hasBackupUrl = true, engineMode = LiveTvEngineMode.AUTO_OTT_HEAL)
        assertEquals(LiveTvHealStage.VLC_HW_PRIMARY, s1)
        val s2 = LiveTvEngineRouter.nextHealStage(s1!!, hasBackupUrl = true, engineMode = LiveTvEngineMode.AUTO_OTT_HEAL)
        assertEquals(LiveTvHealStage.VLC_HW_BACKUP, s2)
        assertNull(LiveTvEngineRouter.nextHealStage(s2!!, hasBackupUrl = true, engineMode = LiveTvEngineMode.AUTO_OTT_HEAL))
    }

    @Test
    fun xtreamAlternativeUrlSwapsM3u8AndTsCleanly() {
        assertEquals(
            "http://iptv.example:8080/live/user/pass/12345.ts",
            LiveTvEngineRouter.buildAlternativeXtreamUrl("http://iptv.example:8080/live/user/pass/12345.m3u8")
        )
        assertEquals(
            "http://iptv.example:8080/live/user/pass/12345.m3u8?token=abc",
            LiveTvEngineRouter.buildAlternativeXtreamUrl("http://iptv.example:8080/live/user/pass/12345.ts?token=abc")
        )
    }

    @Test
    fun remembersWinningEnginePerChannelInAutoModeOnly() {
        assertEquals(
            LiveTvEngineMode.LIBVLC_SW,
            LiveTvEngineRouter.resolveInitialEngineForChannel(LiveTvEngineMode.AUTO_OTT_HEAL, "VLC_SW")
        )
        assertEquals(
            LiveTvEngineMode.MEDIA3_ONLY,
            LiveTvEngineRouter.resolveInitialEngineForChannel(LiveTvEngineMode.MEDIA3_ONLY, "VLC_SW")
        )
    }
}
