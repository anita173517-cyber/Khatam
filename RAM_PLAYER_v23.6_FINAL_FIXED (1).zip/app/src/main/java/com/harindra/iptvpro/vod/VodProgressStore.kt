package com.harindra.iptvpro.vod

import com.harindra.iptvpro.ContentSourceType
import com.harindra.iptvpro.PlaybackProgressEntry
import com.harindra.iptvpro.ProfileStore

/**
 * Dedicated VOD Progress & Completion Store.
 *
 * - Keeps Movie progress (`XTREAM_VOD_MOVIE`) and Series Episode progress (`XTREAM_SERIES_EPISODE`)
 *   strictly separated by stable content identifiers.
 * - Never saves invalid or near-zero positions (< 10 seconds).
 * - Marks content completed ONLY when it genuinely reaches the completion threshold (>= 92% of known duration).
 * - Delegates to existing [ProfileStore] on Android so zero Continue Watching or Watchlist data is ever lost.
 */
interface VodProgressStorage {
    fun saveEntry(entry: PlaybackProgressEntry, accountScope: String)
    fun getEntry(contentId: String, accountScope: String): PlaybackProgressEntry?
    fun getAllEntries(accountScope: String): List<PlaybackProgressEntry>
    fun clearEntry(contentId: String, accountScope: String)
    fun markWatched(contentId: String, accountScope: String)
    fun markUnwatched(contentId: String, accountScope: String)
    fun isWatched(contentId: String, accountScope: String): Boolean
}

class ProfileStoreVodProgressAdapter(private val profileStore: ProfileStore) : VodProgressStorage {
    override fun saveEntry(entry: PlaybackProgressEntry, accountScope: String) {
        profileStore.savePlaybackProgress(
            contentId = entry.contentId,
            positionMs = entry.positionMs,
            durationMs = entry.durationMs,
            seriesKey = entry.seriesKey,
            seasonNumber = entry.seasonNumber,
            episodeNumber = entry.episodeNumber,
            contentType = entry.contentType,
            accountScope = accountScope
        )
    }

    override fun getEntry(contentId: String, accountScope: String): PlaybackProgressEntry? {
        return profileStore.getPlaybackProgress(contentId, accountScope)
    }

    override fun getAllEntries(accountScope: String): List<PlaybackProgressEntry> {
        return profileStore.getContinueWatchingEntries(accountScope)
    }

    override fun clearEntry(contentId: String, accountScope: String) {
        profileStore.clearPlaybackProgress(contentId, accountScope)
    }

    override fun markWatched(contentId: String, accountScope: String) {
        profileStore.markContentWatched(contentId, accountScope)
    }

    override fun markUnwatched(contentId: String, accountScope: String) {
        profileStore.markContentUnwatched(contentId, accountScope)
    }

    override fun isWatched(contentId: String, accountScope: String): Boolean {
        return profileStore.isContentWatched(contentId, accountScope)
    }
}

class InMemoryVodProgressStorage : VodProgressStorage {
    private val entries = LinkedHashMap<String, MutableMap<String, PlaybackProgressEntry>>()
    private val watched = LinkedHashMap<String, MutableSet<String>>()

    override fun saveEntry(entry: PlaybackProgressEntry, accountScope: String) {
        entries.getOrPut(accountScope) { LinkedHashMap() }[entry.contentId] = entry
    }

    override fun getEntry(contentId: String, accountScope: String): PlaybackProgressEntry? {
        return entries[accountScope]?.get(contentId)
    }

    override fun getAllEntries(accountScope: String): List<PlaybackProgressEntry> {
        return entries[accountScope]?.values?.sortedByDescending { it.updatedAtMs }.orEmpty()
    }

    override fun clearEntry(contentId: String, accountScope: String) {
        entries[accountScope]?.remove(contentId)
    }

    override fun markWatched(contentId: String, accountScope: String) {
        watched.getOrPut(accountScope) { LinkedHashSet() }.add(contentId)
    }

    override fun markUnwatched(contentId: String, accountScope: String) {
        watched[accountScope]?.remove(contentId)
    }

    override fun isWatched(contentId: String, accountScope: String): Boolean {
        return watched[accountScope]?.contains(contentId) == true
    }
}

data class VodProgressSaveResult(
    val saved: Boolean,
    val markedCompleted: Boolean,
    val progressPercent: Int
)

class VodProgressStore(private val storage: VodProgressStorage) {

    companion object {
        const val MIN_VALID_POSITION_MS = 10_000L
        const val COMPLETION_THRESHOLD_PERCENT = 92
    }

    fun recordProgress(
        contentType: VodContentType,
        contentId: String,
        positionMs: Long,
        durationMs: Long,
        accountScope: String,
        seriesKey: String = "",
        seasonNumber: Int = 0,
        episodeNumber: Int = 0,
        nowMs: Long = System.currentTimeMillis()
    ): VodProgressSaveResult {
        val cleanId = contentId.trim()
        if (cleanId.isEmpty() || positionMs < MIN_VALID_POSITION_MS) {
            return VodProgressSaveResult(saved = false, markedCompleted = false, progressPercent = 0)
        }
        val safeDuration = durationMs.coerceAtLeast(0L)
        val clampedPos = if (safeDuration > 0L) positionMs.coerceIn(0L, safeDuration) else positionMs
        val percent = if (safeDuration > 0L) {
            ((clampedPos * 100L) / safeDuration).toInt().coerceIn(0, 100)
        } else 0

        if (safeDuration > 0L && percent >= COMPLETION_THRESHOLD_PERCENT) {
            storage.clearEntry(cleanId, accountScope)
            storage.markWatched(cleanId, accountScope)
            return VodProgressSaveResult(saved = true, markedCompleted = true, progressPercent = 100)
        }

        val entry = PlaybackProgressEntry(
            contentId = cleanId,
            positionMs = clampedPos,
            durationMs = safeDuration,
            updatedAtMs = nowMs,
            contentType = contentType.toContentSourceType(),
            seriesKey = if (contentType == VodContentType.SERIES_EPISODE) seriesKey else "",
            seasonNumber = if (contentType == VodContentType.SERIES_EPISODE) seasonNumber else 0,
            episodeNumber = if (contentType == VodContentType.SERIES_EPISODE) episodeNumber else 0
        )
        storage.saveEntry(entry, accountScope)
        return VodProgressSaveResult(saved = true, markedCompleted = false, progressPercent = percent)
    }

    fun getResumePositionMs(contentId: String, accountScope: String, resumeEnabled: Boolean): Long {
        if (!resumeEnabled) return 0L
        val entry = storage.getEntry(contentId.trim(), accountScope) ?: return 0L
        return if (entry.isResumable()) entry.positionMs else 0L
    }

    fun getProgressEntry(contentId: String, accountScope: String): PlaybackProgressEntry? {
        return storage.getEntry(contentId.trim(), accountScope)
    }

    fun getContinueWatchingMovies(accountScope: String): List<PlaybackProgressEntry> {
        return storage.getAllEntries(accountScope)
            .filter { it.contentType == ContentSourceType.XTREAM_VOD_MOVIE && it.isResumable() }
    }

    fun getContinueWatchingSeries(accountScope: String): List<PlaybackProgressEntry> {
        return storage.getAllEntries(accountScope)
            .filter { it.contentType == ContentSourceType.XTREAM_SERIES_EPISODE && it.isResumable() }
    }

    fun getLatestEpisodeForSeries(seriesKey: String, accountScope: String): PlaybackProgressEntry? {
        if (seriesKey.isBlank()) return null
        return storage.getAllEntries(accountScope)
            .filter { it.contentType == ContentSourceType.XTREAM_SERIES_EPISODE && it.seriesKey == seriesKey }
            .maxByOrNull { it.updatedAtMs }
    }

    fun resetForRewatch(contentId: String, accountScope: String) {
        val cleanId = contentId.trim()
        if (cleanId.isEmpty()) return
        storage.clearEntry(cleanId, accountScope)
        storage.markUnwatched(cleanId, accountScope)
    }

    fun isCompleted(contentId: String, accountScope: String): Boolean {
        return storage.isWatched(contentId.trim(), accountScope)
    }
}
