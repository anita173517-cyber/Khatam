package com.harindra.iptvpro.vod

import android.content.Context
import android.media.AudioManager

/**
 * RAM PLAYER v22.0 — Next-Generation VOD Audio Controller.
 *
 * Manages:
 * - Audio track discovery, selection, and preferred language auto-matching
 * - True positive & negative audio sync delay (-5000ms..+5000ms)
 * - Cinema Dialogue & Voice Clarity presets via LibVLC Equalizer + safe gain
 * - Android TV system volume Up / Down / Mute with clean visual feedback
 */
class VodAudioController(
    private val context: Context?,
    private val prefs: VodPreferencesStore
) {
    private var isMuted: Boolean = false
    private var preMuteVolume: Int = -1
    private var currentDialoguePreset: VodDialoguePreset = VodDialoguePreset.NORMAL

    fun getDialoguePreset(): VodDialoguePreset = currentDialoguePreset

    fun cycleDialoguePreset(engine: VodPlayerEngine): VodDialoguePreset {
        currentDialoguePreset = currentDialoguePreset.next()
        engine.applyDialoguePreset(currentDialoguePreset)
        return currentDialoguePreset
    }

    fun applyPreferredAudioTrack(engine: VodPlayerEngine): VodEngineTrack? {
        val prefLang = prefs.getPreferredAudioLanguage().trim().lowercase()
        if (prefLang.isBlank() || prefLang == "original" || prefLang == "auto") return null
        val tracks = engine.getAudioTracks().filter { !it.isOffOption }
        val match = tracks.firstOrNull { it.name.lowercase().contains(prefLang) } ?: return null
        if (!match.isSelected) {
            engine.selectAudioTrack(match.id)
        }
        return match
    }

    fun adjustAudioDelayMs(engine: VodPlayerEngine, deltaMs: Long): Long {
        val next = (engine.getAudioDelayMs() + deltaMs).coerceIn(-5000L, 5000L)
        engine.setAudioDelayMs(next)
        return next
    }

    fun resetAudioDelay(engine: VodPlayerEngine): Long {
        engine.setAudioDelayMs(0L)
        return 0L
    }

    fun formatAudioDelayLabel(delayMs: Long): String = when {
        delayMs == 0L -> "0 ms (In Sync)"
        delayMs > 0L -> "+${delayMs} ms"
        else -> "${delayMs} ms"
    }

    fun adjustSystemVolume(increase: Boolean): Pair<Int, Int> {
        val am = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return 50 to 100
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val nextVol = (if (increase) curVol + 1 else curVol - 1).coerceIn(0, maxVol)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
        isMuted = (nextVol == 0)
        return nextVol to maxVol
    }

    fun toggleMute(): Boolean {
        val am = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (!isMuted && curVol > 0) {
            preMuteVolume = curVol
            am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            isMuted = true
        } else {
            val restore = if (preMuteVolume > 0) preMuteVolume else (am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 2).coerceAtLeast(1)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, restore, 0)
            isMuted = false
        }
        return isMuted
    }

    fun isSystemMuted(): Boolean = isMuted
}
