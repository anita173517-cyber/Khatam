package com.harindra.iptvpro

import android.app.ActivityManager
import android.content.Context
import android.util.Log
import java.io.File

/**
 * RAM PLAYER v23.3 — EXTREME STORAGE OPTIMIZATION & SMART CACHE BUDGET MANAGER.
 *
 * Designed specifically for 512MB–2GB low-end Android TVs where total internal storage is scarce:
 * - Strictly bounds Glide poster/logo LRU disk cache to 24 MB (eliminating Glide's default 250 MB bloat!)
 * - Bounds GZIP-compressed playlist catalog caches (12 MB), GZIP EPG caches (8 MB), and temp/HTTP caches (8 MB)
 * - Keeps total active app cache + catalog storage under ~52 MB even after days of heavy Live TV + VOD usage
 * - Measures real per-category byte usage directly from the filesystem for the Settings Storage Monitor
 * - Safe cleanup NEVER deletes saved Xtream/M3U accounts, playlists, favorites, watchlists, history, or settings
 */
object StorageBudgetManager {

    const val MB = 1024L * 1024L
    const val GLIDE_DISK_CACHE_DIR = "image_manager_disk_cache"
    const val PREF_AUTO_CLEANUP_KEY = "storage_auto_cleanup_v233"

    // Configurable storage caps (Total budget ~52 MB -> safely under 50-60 MB target on 512MB TVs)
    const val MAX_GLIDE_DISK_CACHE_BYTES: Long = 4L * MB
    const val MAX_PLAYLIST_CACHE_BYTES: Long = 4L * MB
    const val MAX_EPG_CACHE_BYTES: Long = 2L * MB
    const val MAX_TEMP_CACHE_BYTES: Long = 2L * MB
    const val MAX_TOTAL_CACHE_BUDGET_BYTES: Long = 12L * MB

    const val EPG_MAX_AGE_MS: Long = 24L * 60L * 60L * 1000L // 24 hours
    const val TEMP_FILE_MAX_AGE_MS: Long = 24L * 60L * 60L * 1000L // 24 hours
    const val LOW_DEVICE_STORAGE_THRESHOLD_BYTES: Long = 250L * MB

    data class StorageSnapshot(
        val appApkSizeBytes: Long,
        val appDataAndPrefsBytes: Long,
        val glideImagesCacheBytes: Long,
        val playlistCacheBytes: Long,
        val epgCacheBytes: Long,
        val tempAndHttpCacheBytes: Long,
        val freeDeviceStorageBytes: Long
    ) {
        val totalManagedCacheBytes: Long
            get() = glideImagesCacheBytes + playlistCacheBytes + epgCacheBytes + tempAndHttpCacheBytes

        val totalAppStorageBytes: Long
            get() = appApkSizeBytes + appDataAndPrefsBytes + totalManagedCacheBytes
    }

    data class CleanupResult(
        val bytesFreed: Long,
        val filesDeleted: Int,
        val triggeredByLowStorage: Boolean
    )

    fun isLowRamDevice(context: Context): Boolean {
        return runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                am.isLowRamDevice || mi.totalMem <= 1536L * MB
            } else {
                false
            }
        }.getOrDefault(false)
    }

    fun recommendedGlideMemoryCacheBytes(context: Context): Long {
        return if (isLowRamDevice(context)) 6L * MB else 12L * MB
    }

    fun recommendedGlideBitmapPoolBytes(context: Context): Long {
        return if (isLowRamDevice(context)) 6L * MB else 12L * MB
    }

    fun isAutoCleanupEnabled(context: Context): Boolean {
        return runCatching {
            context.applicationContext
                .getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                .getBoolean(PREF_AUTO_CLEANUP_KEY, true)
        }.getOrDefault(true)
    }

    fun setAutoCleanupEnabled(context: Context, enabled: Boolean) {
        runCatching {
            context.applicationContext
                .getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_AUTO_CLEANUP_KEY, enabled)
                .apply()
        }
    }

    fun formatSize(bytes: Long): String {
        val safe = bytes.coerceAtLeast(0L)
        return when {
            safe >= MB -> String.format(java.util.Locale.US, "%.1f MB", safe.toDouble() / MB.toDouble())
            safe >= 1024L -> "${safe / 1024L} KB"
            else -> "$safe B"
        }
    }

    fun measureDirectoryBytes(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        if (dir.isFile) return dir.length()
        return runCatching {
            dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        }.getOrDefault(0L)
    }

    fun inspectStorage(context: Context): StorageSnapshot {
        val appCtx = context.applicationContext
        val apkBytes = runCatching {
            val ai = appCtx.applicationInfo
            var sum = File(ai.sourceDir).takeIf { it.exists() }?.length() ?: 0L
            ai.splitSourceDirs?.forEach { p ->
                sum += File(p).takeIf { it.exists() }?.length() ?: 0L
            }
            sum
        }.getOrDefault(0L)

        val glideDir = File(appCtx.cacheDir, GLIDE_DISK_CACHE_DIR)
        val glideBytes = measureDirectoryBytes(glideDir)

        var playlistBytes = 0L
        var epgBytes = 0L
        var otherFilesDirBytes = 0L

        appCtx.filesDir.listFiles()?.forEach { f ->
            val len = measureDirectoryBytes(f)
            when {
                f.name.startsWith("streamx_channels_v1_") || f.name.startsWith("local_playlist_") -> playlistBytes += len
                f.name.startsWith("streamx_epg_") -> epgBytes += len
                else -> otherFilesDirBytes += len
            }
        }

        val totalCacheDirBytes = measureDirectoryBytes(appCtx.cacheDir)
        val tempAndHttpBytes = (totalCacheDirBytes - glideBytes).coerceAtLeast(0L)

        val dataRoot = appCtx.filesDir.parentFile
        val prefsBytes = measureDirectoryBytes(if (dataRoot != null) File(dataRoot, "shared_prefs") else null)
        val dbBytes = measureDirectoryBytes(if (dataRoot != null) File(dataRoot, "databases") else null)
        val appDataBytes = otherFilesDirBytes + prefsBytes + dbBytes

        val freeBytes = runCatching { appCtx.filesDir.usableSpace }.getOrDefault(0L)

        return StorageSnapshot(
            appApkSizeBytes = apkBytes,
            appDataAndPrefsBytes = appDataBytes,
            glideImagesCacheBytes = glideBytes,
            playlistCacheBytes = playlistBytes,
            epgCacheBytes = epgBytes,
            tempAndHttpCacheBytes = tempAndHttpBytes,
            freeDeviceStorageBytes = freeBytes
        )
    }

    /**
     * Enforces LRU caps across Glide images, playlist caches, EPG cache, and temp files.
     * NEVER deletes user accounts, active local playlists, favorites, watchlists, or settings.
     */
    fun enforceStorageBudget(
        context: Context,
        activeLocalPlaylistPaths: Set<String> = emptySet(),
        forceCleanup: Boolean = false
    ): CleanupResult {
        val appCtx = context.applicationContext
        if (!forceCleanup && !isAutoCleanupEnabled(appCtx)) {
            return CleanupResult(0L, 0, false)
        }
        val freeBytes = runCatching { appCtx.filesDir.usableSpace }.getOrDefault(Long.MAX_VALUE)
        val lowStorage = freeBytes < LOW_DEVICE_STORAGE_THRESHOLD_BYTES

        val glideCap = if (lowStorage) 2L * MB else MAX_GLIDE_DISK_CACHE_BYTES
        val playlistCap = if (lowStorage) 3L * MB else MAX_PLAYLIST_CACHE_BYTES
        val epgCap = if (lowStorage) 1L * MB else MAX_EPG_CACHE_BYTES
        val tempCap = if (lowStorage) 1L * MB else MAX_TEMP_CACHE_BYTES

        var freed = 0L
        var deleted = 0
        val now = System.currentTimeMillis()

        // 1. Delete orphaned .tmp files in filesDir and cacheDir
        listOf(appCtx.filesDir, appCtx.cacheDir).forEach { root ->
            root.listFiles()?.forEach { f ->
                if (f.isFile && (f.name.endsWith(".tmp") || f.name.endsWith(".part"))) {
                    val sz = f.length()
                    if (f.delete()) {
                        freed += sz
                        deleted++
                    }
                }
            }
        }

        // 2. Delete orphaned local_playlist_*.m3u copies not referenced by any active saved profile
        val activeNormalized = activeLocalPlaylistPaths.map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        appCtx.filesDir.listFiles { f -> f.isFile && f.name.startsWith("local_playlist_") && f.name.endsWith(".m3u") }
            ?.sortedByDescending { it.lastModified() }
            ?.forEachIndexed { idx, f ->
                val isReferenced = activeNormalized.contains(f.absolutePath) || activeNormalized.contains(f.name)
                if (!isReferenced && idx >= 1 && (now - f.lastModified()) > TEMP_FILE_MAX_AGE_MS) {
                    val sz = f.length()
                    if (f.delete()) {
                        freed += sz
                        deleted++
                    }
                }
            }

        // 3. Enforce LRU cap on Glide disk cache (files only; preserve journal)
        val glideDir = File(appCtx.cacheDir, GLIDE_DISK_CACHE_DIR)
        val (gFreed, gDel) = pruneDirectoryLru(glideDir, glideCap, excludeNames = setOf("journal"))
        freed += gFreed
        deleted += gDel

        // 4. Enforce LRU cap on playlist cache files (streamx_channels_v1_*)
        val playlistFiles = appCtx.filesDir.listFiles { f ->
            f.isFile && f.name.startsWith("streamx_channels_v1_")
        }?.toList().orEmpty()
        val (pFreed, pDel) = pruneFileListLru(playlistFiles, playlistCap)
        freed += pFreed
        deleted += pDel

        // 5. Expire stale EPG cache (>48h or exceeding cap)
        appCtx.filesDir.listFiles { f -> f.isFile && f.name.startsWith("streamx_epg_") }?.forEach { f ->
            if ((now - f.lastModified()) > EPG_MAX_AGE_MS || f.length() > epgCap) {
                val sz = f.length()
                if (f.delete()) {
                    freed += sz
                    deleted++
                }
            }
        }

        // 6. Prune non-Glide temp/HTTP files in cacheDir
        val tempFiles = appCtx.cacheDir.listFiles()?.filter { it.name != GLIDE_DISK_CACHE_DIR }
            ?.flatMap { if (it.isDirectory) it.walkTopDown().filter { c -> c.isFile }.toList() else listOf(it) }
            .orEmpty()
        val (tFreed, tDel) = pruneFileListLru(tempFiles, tempCap)
        freed += tFreed
        deleted += tDel

        if (deleted > 0) {
            Log.i("StreamX", "StorageBudgetManager freed ${formatSize(freed)} ($deleted files, lowStorage=$lowStorage)")
        }
        return CleanupResult(freed, deleted, lowStorage)
    }

    fun pruneDirectoryLru(
        dir: File,
        maxBytes: Long,
        excludeNames: Set<String> = emptySet()
    ): Pair<Long, Int> {
        if (!dir.exists() || !dir.isDirectory) return 0L to 0
        val files = dir.walkTopDown()
            .filter { it.isFile && it.name !in excludeNames }
            .toList()
        return pruneFileListLru(files, maxBytes)
    }

    fun pruneFileListLru(files: List<File>, maxBytes: Long): Pair<Long, Int> {
        if (files.isEmpty()) return 0L to 0
        var total = files.sumOf { it.length() }
        if (total <= maxBytes) return 0L to 0
        var freed = 0L
        var deleted = 0
        val sortedOldestFirst = files.sortedBy { it.lastModified() }
        for (f in sortedOldestFirst) {
            if (total <= maxBytes) break
            val sz = f.length()
            if (f.delete()) {
                total -= sz
                freed += sz
                deleted++
            }
        }
        return freed to deleted
    }
}
