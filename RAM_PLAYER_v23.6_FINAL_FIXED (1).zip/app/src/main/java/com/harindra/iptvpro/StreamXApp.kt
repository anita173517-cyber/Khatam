package com.harindra.iptvpro

import android.app.Application
import android.content.ComponentCallbacks2
import android.util.Log
import com.bumptech.glide.Glide
import com.bumptech.glide.GlideBuilder
import com.bumptech.glide.MemoryCategory
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory
import com.bumptech.glide.load.engine.cache.LruResourceCache
import com.bumptech.glide.request.RequestOptions
import java.util.concurrent.Executors

/**
 * RAM PLAYER v23.3 — Global Storage Budget & 512MB RAM Memory Guard.
 *
 * - Strictly caps Glide disk cache to 24 MB LRU (replacing Glide's 250 MB default that caused 324 MB bloat)
 * - Caps Glide memory cache & bitmap pool to 6 MB each on low-RAM Android TVs with RGB_565 decoding
 * - Automatically enforces the 52 MB total cache budget on startup & low-memory events without touching user data
 */
class StreamXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching {
            val memCap = StorageBudgetManager.recommendedGlideMemoryCacheBytes(this)
            val poolCap = StorageBudgetManager.recommendedGlideBitmapPoolBytes(this)
            val glideBuilder = GlideBuilder()
                .setDiskCache(
                    InternalCacheDiskCacheFactory(
                        this,
                        StorageBudgetManager.GLIDE_DISK_CACHE_DIR,
                        StorageBudgetManager.MAX_GLIDE_DISK_CACHE_BYTES
                    )
                )
                .setMemoryCache(LruResourceCache(memCap))
                .setBitmapPool(LruBitmapPool(poolCap))
                .setDefaultRequestOptions(
                    RequestOptions()
                        .format(DecodeFormat.PREFER_RGB_565)
                        .disallowHardwareConfig()
                )
            Glide.init(this, glideBuilder)
            Glide.get(this).setMemoryCategory(MemoryCategory.LOW)
        }.onFailure {
            runCatching { Glide.get(this).setMemoryCategory(MemoryCategory.LOW) }
        }

        // Delay background storage cleanup by 8s so app startup & Xtream playlist loading have 100% CPU
        Executors.newSingleThreadExecutor().execute {
            runCatching {
                Thread.sleep(8000L)
                val activeLocalPaths = runCatching {
                    ProfileStore(this).all()
                        .map { it.source }
                        .toSet()
                }.getOrDefault(emptySet())
                StorageBudgetManager.enforceStorageBudget(this, activeLocalPaths)
            }
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            Glide.get(this).trimMemory(level)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
                level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
            ) {
                Log.i("StreamX", "Global Memory Guard triggered (level=$level): clearing non-visible caches")
                Glide.get(this).clearMemory()
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                ChannelCacheStore.trimMemoryCache()
                EpgCacheStore.trimMemoryCache()
                XmltvParser.trimProgrammeDetailsCache()
                NetworkClient.evictIdleConnections()
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            Glide.get(this).clearMemory()
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            ChannelCacheStore.trimMemoryCache()
            EpgCacheStore.trimMemoryCache()
            XmltvParser.trimProgrammeDetailsCache()
            NetworkClient.evictIdleConnections()
        }
    }
}
