package com.harindra.iptvpro.vod

/**
 * Dedicated Series Auto-Next & Episode Navigation Controller.
 *
 * - Guarantees Auto-Next NEVER triggers twice for the same episode.
 * - Resolves exact next and previous episodes across seasons cleanly.
 * - Respects user's auto-next enabled setting, countdown duration, and manual cancel.
 */
class VodAutoNextController(
    private var episodes: List<VodEpisodeNavItem> = emptyList()
) {
    private var triggeredForEpisodeId: String = ""
    private var cancelledForEpisodeId: String = ""

    fun updateEpisodes(newEpisodes: List<VodEpisodeNavItem>) {
        episodes = newEpisodes.sortedWith(
            compareBy<VodEpisodeNavItem> { it.seasonNumber }.thenBy { it.episodeNumber }
        )
    }

    fun resetForEpisode(episodeId: String) {
        if (triggeredForEpisodeId != episodeId) {
            triggeredForEpisodeId = ""
        }
        if (cancelledForEpisodeId != episodeId) {
            cancelledForEpisodeId = ""
        }
    }

    fun findNextEpisode(currentEpisodeId: String): VodEpisodeNavItem? {
        if (episodes.isEmpty() || currentEpisodeId.isBlank()) return null
        val idx = episodes.indexOfFirst { it.episodeId == currentEpisodeId }
        if (idx < 0 || idx + 1 >= episodes.size) return null
        val candidate = episodes[idx + 1]
        return if (candidate.episodeId != currentEpisodeId) candidate else null
    }

    fun findPreviousEpisode(currentEpisodeId: String): VodEpisodeNavItem? {
        if (episodes.isEmpty() || currentEpisodeId.isBlank()) return null
        val idx = episodes.indexOfFirst { it.episodeId == currentEpisodeId }
        if (idx <= 0) return null
        val candidate = episodes[idx - 1]
        return if (candidate.episodeId != currentEpisodeId) candidate else null
    }

    /**
     * Checks whether the auto-next overlay should appear near the end of an episode or on STATE_ENDED.
     * Returns the next episode exactly once per currentEpisodeId.
     */
    fun evaluateAutoNextTrigger(
        contentType: VodContentType,
        currentEpisodeId: String,
        positionMs: Long,
        durationMs: Long,
        playbackEnded: Boolean,
        autoNextEnabled: Boolean,
        leadWindowMs: Long = 20_000L
    ): VodEpisodeNavItem? {
        if (contentType != VodContentType.SERIES_EPISODE) return null
        if (!autoNextEnabled || currentEpisodeId.isBlank()) return null
        if (triggeredForEpisodeId == currentEpisodeId || cancelledForEpisodeId == currentEpisodeId) {
            return null
        }

        val inTriggerWindow = playbackEnded || (
            durationMs > 60_000L &&
                positionMs > 0L &&
                (durationMs - positionMs) in 1_000L..leadWindowMs
            )
        if (!inTriggerWindow) return null

        val next = findNextEpisode(currentEpisodeId) ?: return null
        triggeredForEpisodeId = currentEpisodeId
        return next
    }

    fun cancelForEpisode(currentEpisodeId: String) {
        cancelledForEpisodeId = currentEpisodeId
        triggeredForEpisodeId = currentEpisodeId
    }

    fun isCancelledFor(episodeId: String): Boolean = cancelledForEpisodeId == episodeId
}
